<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>New Order Received - <?php echo e($order->order_number); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background: linear-gradient(135deg, #FF9800, #F57C00);
            color: white;
            padding: 30px;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }
        .content {
            background: #f9f9f9;
            padding: 30px;
            border-radius: 0 0 10px 10px;
        }
        .order-details {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .item-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .total-row {
            font-weight: bold;
            font-size: 1.2em;
            color: #FF9800;
            border-top: 2px solid #FF9800;
            padding-top: 15px;
            margin-top: 15px;
        }
        .alert-badge {
            background: #4CAF50;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            display: inline-block;
        }
        .action-button {
            background: #1976D2;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
            display: inline-block;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🎉 New Order Alert!</h1>
        <p>Hello <?php echo e($admin_name); ?>, you have a new order!</p>
        <div class="alert-badge">Order #<?php echo e($order->order_number); ?></div>
    </div>

    <div class="content">
        <h2>Order Summary</h2>
        
        <div class="order-details">
            <p><strong>Customer:</strong> <?php echo e($order->customer_name); ?></p>
            <p><strong>Email:</strong> <?php echo e($order->customer_email); ?></p>
            <p><strong>Phone:</strong> <?php echo e($order->customer_phone); ?></p>
            <p><strong>Shipping Address:</strong><br>
                <?php echo e($order->shipping_address); ?><br>
                <?php echo e($order->city); ?><?php echo e($order->postal_code ? ', ' . $order->postal_code : ''); ?>

            </p>
            <p><strong>Payment Method:</strong> <?php echo e(ucfirst(str_replace('_', ' ', $order->payment_method))); ?></p>
            <p><strong>Order Date:</strong> <?php echo e($order->created_at->format('M d, Y H:i A')); ?></p>
            <?php if($order->notes): ?>
                <p><strong>Customer Notes:</strong> <?php echo e($order->notes); ?></p>
            <?php endif; ?>
        </div>

        <h3>Items Ordered</h3>
        <div class="order-details">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-row">
                    <div>
                        <strong><?php echo e($item->product_name); ?></strong><br>
                        <small>Qty: <?php echo e($item->quantity); ?> × $<?php echo e(number_format($item->price, 2)); ?></small>
                    </div>
                    <div>
                        <strong>$<?php echo e(number_format($item->quantity * $item->price, 2)); ?></strong>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <div class="item-row">
                <div>Subtotal</div>
                <div>$<?php echo e(number_format($order->subtotal, 2)); ?></div>
            </div>
            
            <div class="item-row">
                <div>Tax</div>
                <div>$<?php echo e(number_format($order->tax, 2)); ?></div>
            </div>
            
            <div class="item-row">
                <div>Shipping</div>
                <div>$<?php echo e(number_format($order->shipping, 2)); ?></div>
            </div>
            
            <div class="item-row total-row">
                <div>Total Revenue</div>
                <div>$<?php echo e(number_format($order->total, 2)); ?></div>
            </div>
        </div>

        <div style="text-align: center; margin: 30px 0;">
            <a href="<?php echo e(url('/dashboard')); ?>" class="action-button">
                View Dashboard
            </a>
        </div>

        <p><strong>Action Required:</strong> Please process this order and prepare it for shipping.</p>
        
        <p>This is an automated notification from SMS Store.</p>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\Sale Management System\sms-app\resources\views/emails/new-order-admin.blade.php ENDPATH**/ ?>